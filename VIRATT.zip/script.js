// Add any JavaScript functionality you need here
console.log("Welcome to my portfolio!");
